//
// Created by Dora on 2025. 03. 20..
//

#include "stack.h"

#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void createStack(int capacity, Stack_t* stack){
  stack->capacity = capacity;
  stack->top = -1;
  stack->elements = (int *)malloc(stack->capacity* sizeof(int));
  if(!(stack->elements)){
    printf("error");
    exit(-1);
   }
}
void destroyStack(Stack_t* stack){
  stack->capacity=0;
  stack->top=-1;
  free(stack->elements);
  stack = NULL;
}
bool isFull(Stack_t stack){
    if(stack.top==stack.capacity){
      return true;
    }
    return false;
}
bool isEmpty(Stack_t stack){
   if (stack.top==0)
    {
        return true;
    }
    return false;
}
void push(Stack_t* stack, int item){
  if(isFull(*stack)){
    printf("A verem tele van");
  }
  stack->elements[++stack->top]=item;
}
int pop(Stack_t* stack){
  if(isEmpty(*stack)){
    printf("A verem ures");
    return -1;
  }
  return stack->elements[stack->top--];
}
int peek(Stack_t stack){
  if(isEmpty(stack)){
    printf("A verem ures");
    return -1;
  }
  return stack.elements[stack.top];
}
int size(Stack_t stack) {
    return stack.top + 1;
}

int performOperation(int num1, int num2, char op) {
  switch (op) {
  case '+': return num1 + num2;
  case '-': return num1 - num2;
  case '*': return num1 * num2;
  case '/': return (num2 == 0) ? printf("Cannot divide by 0"), exit(-4),0 : num1 / num2;
  case '%': return (num2 == 0) ? printf("Cannot divide by 0"), exit(-4),0 : num1 % num2;
  default: printf("Invalid operation %c\n",op); exit(-4);
  }
}
/*
void reverseString(const char *text) {
  Stack_t stack;
  createStack(100,&stack);

  for (int i = 0; text[i] != '\0'; i++) {
    push(&stack, text[i]);
  }

  printf("Forditott szoveg: ");
  while (!isEmpty(stack)) {
    printf("%c", pop(&stack));
  }
  printf("\n");
}

bool isPalindrome(const char *text) {
  Stack_t stack;
  createStack(100,&stack);
  int length = strlen(text);
  char cleanedText[100];
  int cleanedIndex = 0;
  for (int i = 0; i < length; i++) {
    if (isalpha(text[i])) {
      cleanedText[cleanedIndex++] = tolower(text[i]);
    }
  }
  cleanedText[cleanedIndex] = '\0';
  for (int i = 0; i < cleanedIndex; i++) {
    push(&stack, cleanedText[i]);
  }
  for (int i = 0; i < cleanedIndex; i++) {
    if (cleanedText[i] != pop(&stack)) {
      return false;
    }
  }
  return true;
}*/